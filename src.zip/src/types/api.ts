export interface Client {
  id: number
  name: string
  doc: string
  email: string
  phone: string
  address: string
  created_at: string
}

export interface CreateClientRequest {
  name: string
  doc: string
  email: string
  phone: string
  address: string
}

export interface Product {
  id: number
  name: string
  unit: string
  min_quantity: number
  current_quantity: number
  created_at: string
}

export interface CreateProductRequest {
  name: string
  unit: string
  min_quantity: number
  current_quantity: number
}

export interface QuantityUpdateRequest {
  delta?: number
  absolute?: number
}

export interface Technician {
  id: number
  name: string
  email?: string | null
  phone?: string | null
  created_at: string
}
export interface CreateTechnicianRequest {
  name: string
  email?: string
  phone?: string
}

export interface ServiceOrderLine {
  praga: string
  product_id: number
  aplicacao: string
  diluicao: string
  quantidade: number
  garantia: string
  product?: Product
}

export interface ServiceOrder {
  id: number
  public_code: string
  client_id: number
  client?: Client
  scheduled_at?: string | null
  status: string
  notes?: string | null
  lines: ServiceOrderLine[]
  technicians?: Technician[]
  created_at: string
}

export interface CreateServiceOrderRequest {
  client_id: number
  scheduled_at?: string
  notes?: string
  technician_ids?: number[]
  lines: ServiceOrderLine[]
}

export interface PaginatedResponse<T> {
  items: T[]
  next_cursor?: string | null
}

export interface CalendarEvent {
  id: number
  title: string
  start: string
  end?: string | null
}

export interface DashboardStats {
  open_orders: number
  in_progress_orders: number
  completed_orders: number
  critical_products: number
}

export interface AuthLoginRequest { email: string; password: string }
export interface AuthLoginResponse { access_token: string }

// --- FAES (avaliação) – campos genéricos alinhados ao backend descrito ---
export interface EvaluationLine {
  praga?: string
  area?: string
  observacao?: string
}

export interface Evaluation {
  id: number
  client_id: number
  notes?: string | null
  lines: EvaluationLine[]
  created_at: string
}

export interface CreateEvaluationRequest {
  client_id: number
  notes?: string
  lines: EvaluationLine[]
}
