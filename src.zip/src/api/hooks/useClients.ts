import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "../client";
import { Client, CreateClientRequest, PaginatedResponse } from "@/types/api";

export function useClients(search = "", cursor = "", limit = 20) {
  return useQuery({
    queryKey: ["clients", search, cursor, limit],
    queryFn: async () => {
      const res = await apiClient.get("/clients", {
        params: { search, cursor, limit },
      });
      return res.data;
    },
    staleTime: 30000,
  });
}

export function useCreateClient() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (payload) => {
      const res = await apiClient.post("/clients", payload);
      return res.data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["clients"] });
    },
  });
}

// ✅ NOVO: buscar UM cliente por ID (para auto-preencher a FAES via ?client_id=... ou seletor)
export function useClientById(id) {
  return useQuery({
    queryKey: ["client", id],
    enabled: !!id,
    queryFn: async () => {
      const res = await apiClient.get(`/clients/${id}`);
      return res.data;
    },
    staleTime: 30000,
  });
}
