import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiClient } from "../client";
import {
  ServiceOrder,
  CreateServiceOrderRequest,
  PaginatedResponse,
} from "@/types/api";
import { generateIdempotencyKey } from "@/lib/idempotency";
import toast from "react-hot-toast";

export function useServiceOrders(
  clientId?: number,
  status?: string,
  dateFrom?: string,
  dateTo?: string,
  cursor: string = "",
  limit: number = 20
) {
  return useQuery({
    queryKey: [
      "service-orders",
      clientId,
      status,
      dateFrom,
      dateTo,
      cursor,
      limit,
    ],
    queryFn: async (): Promise<PaginatedResponse<ServiceOrder>> => {
      const params: any = { cursor, limit };
      if (clientId) params.client_id = clientId;
      if (status) params.status = status;
      if (dateFrom) params.date_from = dateFrom;
      if (dateTo) params.date_to = dateTo;
      const res = await apiClient.get("/service-orders", { params });
      return res.data;
    },
    staleTime: 30000,
  });
}

export function useCreateServiceOrder() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (
      data: CreateServiceOrderRequest
    ): Promise<ServiceOrder> => {
      const res = await apiClient.post("/service-orders", data, {
        headers: { "Idempotency-Key": generateIdempotencyKey() },
      });
      return res.data;
    },
    onSuccess: () => {
      toast.success("OS criada com sucesso!");
      qc.invalidateQueries({ queryKey: ["service-orders"] });
    },
  });
}

export function useServiceOrderPdf() {
  return useMutation({
    mutationFn: async ({
      id,
      template = "os_padrao",
    }: {
      id: number;
      template?: string;
    }) => {
      const response = await apiClient.get(`/service-orders/${id}/pdf`, {
        params: { template },
        responseType: "blob",
      });
      return response.data as Blob;
    },
    onSuccess: (blob) => {
      const url = URL.createObjectURL(blob);
      window.open(url, "_blank");
      URL.revokeObjectURL(url);
    },
    onError: () => toast.error("Erro ao gerar PDF"),
  });
}

// ✅ Buscar UMA OS por ID
export function useServiceOrder(id?: number | string) {
  return useQuery({
    queryKey: ["service-order", id],
    enabled: !!id && String(id).length > 0,
    queryFn: async (): Promise<ServiceOrder> => {
      const res = await apiClient.get(`/service-orders/${id}`);
      return res.data;
    },
    staleTime: 30000,
  });
}
