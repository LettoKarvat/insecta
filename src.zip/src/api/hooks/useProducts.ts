import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { apiClient } from "../client"
import { Product, CreateProductRequest, QuantityUpdateRequest, PaginatedResponse } from "@/types/api"

export function useProducts(onlyCritical: boolean = false, cursor: string = "", limit: number = 50) {
  return useQuery({
    queryKey: ["products", onlyCritical, cursor, limit],
    queryFn: async (): Promise<PaginatedResponse<Product>> => {
      const res = await apiClient.get("/products", { params: { only_critical: onlyCritical, cursor, limit } })
      return res.data
    },
    staleTime: 30000,
  })
}

export function useCreateProduct() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: async (payload: CreateProductRequest): Promise<Product> => {
      const res = await apiClient.post("/products", payload)
      return res.data
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["products"] })
    },
  })
}

export function useUpdateProductQuantity(id: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: async (payload: QuantityUpdateRequest): Promise<Product> => {
      const res = await apiClient.patch(`/products/${id}/quantity`, payload)
      return res.data
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["products"] })
    },
  })
}
