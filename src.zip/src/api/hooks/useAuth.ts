import { useMutation, useQueryClient } from '@tanstack/react-query'
import { apiClient } from '../client'
import { AuthLoginRequest, AuthLoginResponse } from '@/types/api'
import toast from 'react-hot-toast'

export function useLogin() {
  const queryClient = useQueryClient()
  
  return useMutation({
    mutationFn: async (data: AuthLoginRequest): Promise<AuthLoginResponse> => {
      const response = await apiClient.post('/auth/login', data)
      return response.data
    },
    onSuccess: (data) => {
      localStorage.setItem('auth_token', data.access_token)
      toast.success('Login realizado com sucesso!')
      queryClient.invalidateQueries()
    },
  })
}

export function useLogout() {
  const queryClient = useQueryClient()
  
  return useMutation({
    mutationFn: async () => {
      localStorage.removeItem('auth_token')
      queryClient.clear()
    },
    onSuccess: () => {
      toast.success('Logout realizado com sucesso!')
    },
  })
}