import axios, { AxiosError } from "axios"
import toast from "react-hot-toast"
import { getApiBaseUrl } from "@/lib/api-base"

const API_URL = getApiBaseUrl()
const ENABLE_AUTH = (import.meta.env.VITE_ENABLE_AUTH === "true")

export const apiClient = axios.create({
  baseURL: API_URL,
  headers: { "Content-Type": "application/json" },
})

apiClient.interceptors.request.use((config) => {
  if (ENABLE_AUTH) {
    const token = localStorage.getItem("auth_token")
    if (token) config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

apiClient.interceptors.response.use(
  (res) => res,
  (error: AxiosError) => {
    // Tenta RFC7807
    const data: any = error.response?.data
    const message = (data && (data.detail || data.title)) || "Erro de conexão"
    toast.error(message)
    return Promise.reject(error)
  }
)

export default apiClient
