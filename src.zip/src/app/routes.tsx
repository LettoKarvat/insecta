import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { MainLayout } from "@/components/layout/main-layout";
import { Dashboard } from "@/pages/dashboard/dashboard";
import { Clients } from "@/pages/clients/clients";
import { Products } from "@/pages/products/products";
import { ServiceOrders } from "@/pages/service-orders/service-orders";
import { NewServiceOrder } from "@/pages/service-orders/new-service-order";
import { Calendar } from "@/pages/calendar/calendar";
import { Settings } from "@/pages/settings/settings";
// ✅ importe a página de novo produto
import { NewProduct } from "@/pages/products/new-product";
import FAESFormPage from "@/pages/faes/FAESFormPage";

const router = createBrowserRouter([
  {
    path: "/",
    element: <MainLayout />,
    // (opcional) um errorElement simples para não estourar overlay feio
    // errorElement: <div style={{padding:16}}>Página não encontrada.</div>,
    children: [
  { path: "faes/nova", element: <FAESFormPage /> },
      { index: true, element: <Dashboard /> },
      { path: "clientes", element: <Clients /> },
      { path: "produtos", element: <Products /> },
      // ✅ rota que resolve /produtos/novo
      { path: "produtos/novo", element: <NewProduct /> },
      { path: "ordens-servico", element: <ServiceOrders /> },
      { path: "ordens-servico/nova", element: <NewServiceOrder /> },
      { path: "agenda", element: <Calendar /> },
      { path: "configuracoes", element: <Settings /> },
    ],
  },
]);

export function AppRoutes() {
  return <RouterProvider router={router} />;
}
