import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { CreateClientRequest } from "@/types/api"

const clientSchema = z.object({
  name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  doc: z.string().min(11, "Documento inválido"),
  email: z.string().email("Email inválido"),
  phone: z.string().min(10, "Telefone inválido"),
  address: z.string().min(5, "Endereço deve ter pelo menos 5 caracteres"),
})

export function ClientForm({ onSubmit }: { onSubmit: (data: CreateClientRequest) => void }) {
  const { register, handleSubmit, formState: { errors } } = useForm<CreateClientRequest>({
    resolver: zodResolver(clientSchema),
  })

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Nome *</Label>
        <Input id="name" {...register("name")} placeholder="Cliente Exemplo LTDA" />
        {errors.name && <p className="text-sm text-destructive">{errors.name.message}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="doc">Documento *</Label>
        <Input id="doc" {...register("doc")} placeholder="00.000.000/0000-00" />
        {errors.doc && <p className="text-sm text-destructive">{errors.doc.message}</p>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="email">Email *</Label>
          <Input id="email" type="email" {...register("email")} placeholder="exemplo@email.com" />
          {errors.email && <p className="text-sm text-destructive">{errors.email.message}</p>}
        </div>
        <div className="space-y-2">
          <Label htmlFor="phone">Telefone *</Label>
          <Input id="phone" {...register("phone")} placeholder="(41) 99999-9999" />
          {errors.phone && <p className="text-sm text-destructive">{errors.phone.message}</p>}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="address">Endereço *</Label>
        <Input id="address" {...register("address")} placeholder="Rua X, 123 - Centro" />
        {errors.address && <p className="text-sm text-destructive">{errors.address.message}</p>}
      </div>

      <div className="flex justify-end">
        <Button type="submit">Salvar</Button>
      </div>
    </form>
  )
}
