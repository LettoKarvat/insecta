import { Search, Bell, Sun, Moon, User } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'
import { useTheme } from '@/app/providers/theme-provider'
import { useState } from 'react'
import { debounce } from '@/lib/utils'

export function Topbar() {
  const { theme, setTheme } = useTheme()
  const [searchTerm, setSearchTerm] = useState('')
  
  const debouncedSearch = debounce((value: string) => {
    console.log('Global search:', value)
    // Implementar busca global aqui
  }, 300)
  
  const handleSearch = (value: string) => {
    setSearchTerm(value)
    debouncedSearch(value)
  }
  
  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light')
  }
  
  return (
    <div className="h-16 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 px-6 flex items-center justify-between">
      <div className="flex items-center gap-4 flex-1 max-w-md">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Buscar clientes, produtos, ordens..."
            value={searchTerm}
            onChange={(e) => handleSearch(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Sun className="h-4 w-4" />
          <Switch
            checked={theme === 'dark'}
            onCheckedChange={toggleTheme}
            aria-label="Alternar tema"
          />
          <Moon className="h-4 w-4" />
        </div>
        
        <Button variant="ghost" size="icon">
          <Bell className="h-4 w-4" />
        </Button>
        
        <Button variant="ghost" size="icon">
          <User className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}