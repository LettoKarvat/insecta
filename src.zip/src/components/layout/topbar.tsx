export function Topbar() {
  return <div className="h-16 border-b bg-background" />;
}
