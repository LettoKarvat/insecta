import { useState } from "react"
import { Minus, Plus, Edit } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Product } from "@/types/api"
import { motion } from "framer-motion"

export function QuantityEditor({
  product,
  onChange,
  loading = false,
}: {
  product: Product
  onChange: (value: number, absolute?: boolean) => void
  loading?: boolean
}) {
  const [open, setOpen] = useState(false)
  const [value, setValue] = useState<number>(product.current_quantity)

  const handleQuickAdjust = (delta: number) => {
    onChange(delta, false)
  }

  const handleSaveAbsolute = () => {
    onChange(value, true)
    setOpen(false)
  }

  return (
    <div className="flex items-center gap-2">
      <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => handleQuickAdjust(-1)} disabled={loading}>
        <Minus className="h-3 w-3" />
      </Button>

      <motion.div key={product.current_quantity} initial={{ scale: 1.1 }} animate={{ scale: 1 }} className="min-w-12 text-center font-medium">
        {product.current_quantity}
      </motion.div>

      <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => handleQuickAdjust(1)} disabled={loading}>
        <Plus className="h-3 w-3" />
      </Button>

      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setOpen(true)} disabled={loading}>
        <Edit className="h-3 w-3" />
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Definir quantidade</DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            <Label>Quantidade atual</Label>
            <Input type="number" value={value} onChange={(e) => setValue(Number(e.target.value))} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button onClick={handleSaveAbsolute}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
