import { useState } from "react";
import { PageShell } from "@/components/layout/page-shell";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/data-table/data-table";
import { Badge } from "@/components/ui/badge";
import {
  useServiceOrders,
  useServiceOrderPdf,
} from "@/api/hooks/useServiceOrders";
import { ServiceOrder } from "@/types/api";
import { Plus, FileText } from "lucide-react";
import { formatDateTime } from "@/lib/utils";
import { Link, useNavigate } from "react-router-dom";

function getStatusBadge(status: string) {
  const map: Record<
    string,
    { label: string; variant: "default" | "secondary" | "destructive" }
  > = {
    Aberto: { label: "Aberto", variant: "secondary" },
    "Em andamento": { label: "Em andamento", variant: "default" },
    Concluído: { label: "Concluído", variant: "default" },
    Cancelado: { label: "Cancelado", variant: "destructive" },
  };
  const cfg = map[status] ?? { label: status, variant: "secondary" as const };
  return <Badge variant={cfg.variant}>{cfg.label}</Badge>;
}

export function ServiceOrders() {
  const [cursor, setCursor] = useState("");
  const navigate = useNavigate();
  const { data, isLoading } = useServiceOrders(
    undefined,
    undefined,
    undefined,
    undefined,
    cursor,
    20
  );
  const pdf = useServiceOrderPdf();

  const columns = [
    {
      key: "public_code",
      title: "Código",
      render: (_: any, item: ServiceOrder) => (
        <Link
          to={`/ordens-servico/${item.id}`}
          className="text-primary underline"
        >
          {item.public_code}
        </Link>
      ),
    },
    {
      key: "client",
      title: "Cliente",
      render: (_: any, item: ServiceOrder) =>
        item.client?.name ?? `#${item.client_id}`,
    },
    {
      key: "scheduled_at",
      title: "Agendado para",
      render: (value: string) => (value ? formatDateTime(value) : "-"),
      sortable: true,
    },
    {
      key: "status",
      title: "Status",
      render: (value: string) => getStatusBadge(value),
    },
    {
      key: "lines",
      title: "Itens",
      render: (_: any, item: ServiceOrder) => item.lines?.length ?? 0,
    },
    {
      key: "actions",
      title: "Ações",
      render: (_: any, item: ServiceOrder) => (
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => pdf.mutate({ id: item.id, template: "os_verde" })}
          >
            <FileText className="h-4 w-4 mr-2" /> PDF
          </Button>
        </div>
      ),
    },
  ];

  const emptyState = (
    <div className="text-center py-10">
      <FileText className="h-12 w-12 text-muted-foreground mb-4" />
      <h3 className="text-lg font-medium mb-2">Nenhuma OS encontrada</h3>
      <p className="text-muted-foreground mb-4">
        Crie sua primeira ordem de serviço
      </p>
      <Link to="/ordens-servico/nova">
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Nova OS
        </Button>
      </Link>
    </div>
  );

  return (
    <PageShell
      title="Ordens de Serviço"
      description="Gerencie as ordens de serviço"
      action={
        <Link to="/ordens-servico/nova">
          <Button>
            <Plus className="h-4 w-4 mr-2" /> Nova OS
          </Button>
        </Link>
      }
    >
      <DataTable<ServiceOrder>
        data={data?.items || []}
        columns={columns as any}
        loading={isLoading}
        hasMore={!!data?.next_cursor}
        onLoadMore={() => setCursor(data?.next_cursor || "")}
        emptyState={emptyState}
      />
    </PageShell>
  );
}
