import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { PageShell } from "@/components/layout/page-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { useCreateProduct } from "@/api/hooks/useProducts";

const schema = z.object({
  name: z.string().min(1, "Informe o nome"),
  unit: z.string().min(1, "Informe a unidade (ex.: un, L, kg)"),
  min_quantity: z.coerce.number().nonnegative("Mínimo não pode ser negativo"),
  current_quantity: z.coerce
    .number()
    .nonnegative("Quantidade atual não pode ser negativa"),
});

type FormData = z.infer<typeof schema>;

export function NewProduct() {
  const navigate = useNavigate();
  const createProduct = useCreateProduct();

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", unit: "", min_quantity: 0, current_quantity: 0 },
  });

  const onSubmit = async (data: FormData) => {
    try {
      await createProduct.mutateAsync(data);
      toast.success("Produto criado!");
      navigate("/produtos");
    } catch {
      // erros já tosteados no hook
    }
  };

  return (
    <PageShell
      title="Novo Produto"
      description="Cadastre um novo item de estoque"
    >
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 max-w-xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="md:col-span-2">
            <Label>Nome</Label>
            <Input placeholder="Ex.: Gel Mata-Barata" {...register("name")} />
            {errors.name && (
              <p className="text-sm text-red-600 mt-1">
                {String(errors.name.message)}
              </p>
            )}
          </div>
          <div>
            <Label>Unidade</Label>
            <Input placeholder="Ex.: un, L, kg" {...register("unit")} />
            {errors.unit && (
              <p className="text-sm text-red-600 mt-1">
                {String(errors.unit.message)}
              </p>
            )}
          </div>
          <div>
            <Label>Qtd. Mínima</Label>
            <Input
              type="number"
              step="1"
              {...register("min_quantity", { valueAsNumber: true })}
            />
            {errors.min_quantity && (
              <p className="text-sm text-red-600 mt-1">
                {String(errors.min_quantity.message)}
              </p>
            )}
          </div>
          <div>
            <Label>Qtd. Atual</Label>
            <Input
              type="number"
              step="1"
              {...register("current_quantity", { valueAsNumber: true })}
            />
            {errors.current_quantity && (
              <p className="text-sm text-red-600 mt-1">
                {String(errors.current_quantity.message)}
              </p>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <Button
            type="button"
            variant="outline"
            onClick={() => navigate("/produtos")}
          >
            Cancelar
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            Salvar
          </Button>
        </div>
      </form>
    </PageShell>
  );
}
