import { useState } from "react";
import { PageShell } from "@/components/layout/page-shell";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/data-table/data-table";
import { QuantityEditor } from "@/components/quantity-editor/quantity-editor";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useProducts, useUpdateProductQuantity } from "@/api/hooks/useProducts";
import { Product } from "@/types/api";
import { Package, AlertTriangle } from "lucide-react";
import { useNavigate } from "react-router-dom";

export function Products() {
  const navigate = useNavigate();
  const [onlyCritical, setOnlyCritical] = useState(false);
  const [cursor, setCursor] = useState("");

  const { data, isLoading } = useProducts(onlyCritical, cursor);
  const updateQuantityMutation = useUpdateProductQuantity();

  const handleQuantityUpdate = (
    id: number,
    data: { delta?: number; absolute?: number }
  ) => {
    updateQuantityMutation.mutate({ id, data });
  };

  const columns = [
    {
      key: "name",
      title: "Produto",
      sortable: true,
    },
    {
      key: "unit",
      title: "Unidade",
    },
    {
      key: "min_quantity",
      title: "Mínimo",
    },
    {
      key: "current_quantity",
      title: "Atual",
      render: (value: number, item: Product) => {
        const isCritical = value <= item.min_quantity;
        return (
          <div className="flex items-center gap-2">
            <span className={isCritical ? "font-bold text-destructive" : ""}>
              {value}
            </span>
            {isCritical && (
              <Badge variant="destructive" className="text-xs">
                Crítico
              </Badge>
            )}
          </div>
        );
      },
    },
    {
      key: "actions",
      title: "Ações",
      render: (value: any, item: Product) => (
        <QuantityEditor
          product={item}
          onUpdate={handleQuantityUpdate}
          loading={updateQuantityMutation.isPending}
        />
      ),
    },
  ];

  const emptyState = (
    <div className="flex flex-col items-center justify-center py-12">
      <Package className="h-12 w-12 text-muted-foreground mb-4" />
      <h3 className="text-lg font-medium mb-2">
        {onlyCritical ? "Nenhum produto crítico" : "Nenhum produto encontrado"}
      </h3>
      <p className="text-muted-foreground mb-4">
        {onlyCritical
          ? "Todos os produtos estão com estoque adequado"
          : "Cadastre seus produtos para controlar o estoque"}
      </p>
    </div>
  );

  return (
    <PageShell
      title="Produtos e Estoque"
      description="Gerencie seus produtos e controle o estoque"
      action={
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Switch
              id="only-critical"
              checked={onlyCritical}
              onCheckedChange={setOnlyCritical}
            />
            <Label htmlFor="only-critical" className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              Somente críticos
            </Label>
          </div>
          <Button onClick={() => navigate("/produtos/novo")}>
            <Package className="h-4 w-4 mr-2" />
            Novo Produto
          </Button>
        </div>
      }
    >
      <DataTable
        data={data?.items || []}
        columns={columns}
        loading={isLoading}
        hasMore={!!data?.next_cursor}
        onLoadMore={() => setCursor(data?.next_cursor || "")}
        emptyState={emptyState}
      />
    </PageShell>
  );
}
