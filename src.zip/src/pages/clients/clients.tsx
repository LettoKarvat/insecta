import { useState } from 'react'
import { PageShell } from '@/components/layout/page-shell'
import { Button } from '@/components/ui/button'
import { DataTable } from '@/components/data-table/data-table'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { ClientForm } from '@/components/forms/client-form'
import { useClients, useCreateClient } from '@/api/hooks/useClients'
import { Client, CreateClientRequest } from '@/types/api'
import { Plus, Users } from 'lucide-react'
import { formatDate } from '@/lib/utils'

export function Clients() {
  const [search, setSearch] = useState('')
  const [cursor, setCursor] = useState('')
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  
  const { data, isLoading } = useClients(search, cursor)
  const createClientMutation = useCreateClient()
  
  const handleCreateClient = (clientData: CreateClientRequest) => {
    createClientMutation.mutate(clientData, {
      onSuccess: () => {
        setIsCreateModalOpen(false)
      }
    })
  }
  
  const columns = [
    {
      key: 'name',
      title: 'Nome',
      sortable: true,
    },
    {
      key: 'doc',
      title: 'CPF/CNPJ',
    },
    {
      key: 'email',
      title: 'Email',
    },
    {
      key: 'phone',
      title: 'Telefone',
    },
    {
      key: 'created_at',
      title: 'Cadastrado em',
      render: (value: string) => formatDate(value),
    },
  ]
  
  const emptyState = (
    <div className="flex flex-col items-center justify-center py-12">
      <Users className="h-12 w-12 text-muted-foreground mb-4" />
      <h3 className="text-lg font-medium mb-2">Nenhum cliente encontrado</h3>
      <p className="text-muted-foreground mb-4">
        Cadastre seu primeiro cliente para começar
      </p>
      <Button onClick={() => setIsCreateModalOpen(true)}>
        <Plus className="h-4 w-4 mr-2" />
        Cadastrar Cliente
      </Button>
    </div>
  )
  
  return (
    <PageShell
      title="Clientes"
      description="Gerencie sua base de clientes"
      action={
        <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Novo Cliente
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Cadastrar Novo Cliente</DialogTitle>
            </DialogHeader>
            <ClientForm 
              onSubmit={handleCreateClient}
              loading={createClientMutation.isPending}
            />
          </DialogContent>
        </Dialog>
      }
    >
      <DataTable
        data={data?.items || []}
        columns={columns}
        loading={isLoading}
        searchValue={search}
        onSearchChange={setSearch}
        hasMore={!!data?.next_cursor}
        onLoadMore={() => setCursor(data?.next_cursor || '')}
        emptyState={emptyState}
      />
    </PageShell>
  )
}