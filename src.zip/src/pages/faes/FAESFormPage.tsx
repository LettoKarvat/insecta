import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { useSearchParams } from "react-router-dom";
import { useServiceOrder } from "@/api/hooks/useServiceOrders";
import { useClients, useClientById } from "@/api/hooks/useClients";

// ===== Tipos do schema =====
type FieldType =
  | "text"
  | "textarea"
  | "number"
  | "date"
  | "select"
  | "multiselect"
  | "checkbox"
  | "radio"
  | "file"
  | "signature"
  | "repeater";

interface FieldBase {
  id: string;
  label: string;
  type: FieldType;
  required?: boolean;
  placeholder?: string;
  description?: string;
  options?: string[];
  columns?: number;
}
interface FieldRepeater extends FieldBase {
  type: "repeater";
  minItems?: number;
  maxItems?: number;
  children: Field[];
}
type Field = FieldBase | FieldRepeater;

interface Section {
  id: string;
  title: string;
  description?: string;
  fields: Field[];
}
interface FAESchema {
  version: string;
  title: string;
  clientSlug?: string;
  serviceSlug?: string;
  sections: Section[];
}

type JsonValue =
  | string
  | number
  | boolean
  | null
  | File
  | (string | number | boolean | null | File)[]
  | Record<string, any>;

// ===== Helpers =====
const cls = (...c: (string | undefined | false)[]) =>
  c.filter(Boolean).join(" ");
const iso = (s?: string) => (s ? s.slice(0, 10) : "");
const safe = (v: any) => (typeof v === "string" ? v : v ?? "");
const mapClientToFields = (c: any) => ({
  cliente_nome: safe(c?.name),
  cliente_cnpj: safe(c?.doc),
  cliente_endereco: safe(c?.address),
  cliente_cidade_uf: "",
  cliente_cep: "",
});

function toInitialValues(schema: FAESchema) {
  const values: Record<string, JsonValue> = {};
  for (const s of schema.sections)
    for (const f of s.fields) {
      if (f.type === "repeater") values[f.id] = [];
      else if (f.type === "checkbox" || f.type === "multiselect")
        values[f.id] = [];
      else values[f.id] = "";
    }
  return values;
}
function setDeep(obj: any, path: string, value: any) {
  obj[path] = value;
}

// ===== Schema =====
const DEFAULT_SCHEMA: FAESchema = {
  version: "1.0",
  title: "Ficha Avaliativa de Execução de Serviço",
  sections: [
    {
      id: "identificacao",
      title: "Identificação",
      description: "Dados básicos do cliente, OS e responsáveis.",
      fields: [
        {
          id: "cliente_nome",
          label: "Cliente",
          type: "text",
          required: true,
          columns: 2,
        },
        {
          id: "cliente_cnpj",
          label: "CNPJ/CPF do Cliente",
          type: "text",
          columns: 1,
        },
        { id: "cliente_endereco", label: "Endereço", type: "text", columns: 2 },
        {
          id: "cliente_cidade_uf",
          label: "Cidade/UF",
          type: "text",
          columns: 1,
        },
        { id: "cliente_cep", label: "CEP", type: "text", columns: 1 },
        {
          id: "os_numero",
          label: "Nº da OS",
          type: "text",
          required: true,
          columns: 1,
        },
        {
          id: "area_aplicacao",
          label: "Área de Aplicação",
          type: "select",
          options: ["Residencial", "Comercial", "Industrial", "Outros"],
          columns: 1,
        },
        {
          id: "area_tratada_m2",
          label: "Área Tratada (m²)",
          type: "number",
          columns: 1,
        },
        {
          id: "data_emissao",
          label: "Data de Emissão",
          type: "date",
          required: true,
          columns: 1,
        },
        {
          id: "responsavel_tecnico",
          label: "Responsável Técnico",
          type: "text",
          columns: 2,
        },
        { id: "crea", label: "CREA/Registro", type: "text", columns: 1 },
        { id: "aplicador", label: "Aplicador", type: "text", columns: 1 },
        {
          id: "licenca_sanitaria",
          label: "Licença Sanitária",
          type: "text",
          columns: 1,
        },
      ],
    },
    {
      id: "escopo",
      title: "Escopo do Serviço",
      fields: [
        {
          id: "escopo_texto",
          label: "Descrição do escopo",
          type: "textarea",
          required: true,
        },
      ],
    },
    {
      id: "produtos",
      title: "Produtos Utilizados",
      description:
        "Registre cada produto aplicado conforme rótulo/FISPQ e lote.",
      fields: [
        {
          id: "produtos_repeater",
          label: "Lista de produtos",
          type: "repeater",
          minItems: 1,
          children: [
            { id: "produto", label: "Produto", type: "text", required: true },
            { id: "principio_ativo", label: "Princípio ativo", type: "text" },
            { id: "registro_ms", label: "Registro ANVISA/MS", type: "text" },
            { id: "diluente", label: "Diluente", type: "text" },
            { id: "quantidade", label: "Quantidade aplicada", type: "text" },
            { id: "praga_alvo", label: "Praga alvo", type: "text" },
            { id: "equipamento", label: "Equipamento", type: "text" },
            { id: "antidoto", label: "Antídoto/Tratamento", type: "text" },
            { id: "lote", label: "Lote", type: "text" },
            { id: "validade", label: "Validade", type: "date" },
          ],
        },
      ],
    },
    {
      id: "metodos",
      title: "Métodos Utilizados",
      fields: [
        {
          id: "metodos_utilizados",
          label: "Métodos",
          type: "multiselect",
          options: [
            "Pulverização residual",
            "Injeção em madeiras",
            "Barreira química",
            "Outros",
          ],
          required: true,
        },
        {
          id: "metodos_outros",
          label: "Outros (descrever)",
          type: "text",
          placeholder: "Se houver",
          columns: 2,
        },
      ],
    },
    {
      id: "cronograma",
      title: "Cronograma/Execução",
      fields: [
        {
          id: "execucoes",
          label: "Execuções",
          type: "repeater",
          children: [
            { id: "data", label: "Data", type: "date", required: true },
            {
              id: "atividade",
              label: "Atividade/Etapa",
              type: "text",
              required: true,
            },
            { id: "observacoes", label: "Observações", type: "text" },
          ],
        },
      ],
    },
    {
      id: "seguranca",
      title: "Segurança e EPIs",
      fields: [
        {
          id: "epis_utilizados",
          label: "EPIs",
          type: "checkbox",
          options: ["Luvas", "Máscara", "Óculos", "Avental", "Botas"],
        },
        {
          id: "reentrada_horas",
          label: "Tempo de reentrada (horas)",
          type: "number",
          placeholder: "Ex.: 6",
        },
        {
          id: "recomendacoes_pos",
          label: "Recomendações pós-aplicação",
          type: "textarea",
          placeholder: "Ex.: evitar limpeza úmida por 24h",
        },
      ],
    },
    {
      id: "registros",
      title: "Registros e Lotes",
      fields: [
        {
          id: "registros_repeater",
          label: "Lotes/Registros",
          type: "repeater",
          children: [
            { id: "produto", label: "Produto", type: "text" },
            { id: "lote", label: "Lote", type: "text" },
            { id: "fabricante", label: "Fabricante", type: "text" },
            { id: "validade", label: "Validade", type: "date" },
          ],
        },
      ],
    },
    {
      id: "avaliacao",
      title: "Métricas Avaliativas (0–10)",
      fields: [
        {
          id: "nota_cronograma",
          label: "Cumprimento do cronograma",
          type: "number",
          placeholder: "0–10",
        },
        {
          id: "nota_qualidade",
          label: "Qualidade da aplicação",
          type: "number",
          placeholder: "0–10",
        },
        {
          id: "nota_comunicacao",
          label: "Comunicação com o cliente",
          type: "number",
          placeholder: "0–10",
        },
        {
          id: "nota_organizacao",
          label: "Organização/Limpeza",
          type: "number",
          placeholder: "0–10",
        },
        {
          id: "nota_seguranca",
          label: "Segurança/EPIs",
          type: "number",
          placeholder: "0–10",
        },
        {
          id: "nota_documentacao",
          label: "Documentação/Registros",
          type: "number",
          placeholder: "0–10",
        },
        {
          id: "avaliacao_observacoes",
          label: "Observações gerais",
          type: "textarea",
        },
      ],
    },
    {
      id: "inspecoes",
      title: "Inspeções/Reinspeções",
      fields: [
        {
          id: "inspecoes_repeater",
          label: "Inspeções",
          type: "repeater",
          children: [
            { id: "data", label: "Data", type: "date" },
            {
              id: "tipo",
              label: "Tipo",
              type: "select",
              options: ["Inspeção", "Reinspeção"],
              placeholder: "Inspeção",
            },
            { id: "assinatura", label: "Assinatura (upload)", type: "file" },
          ],
        },
      ],
    },
    {
      id: "assinaturas",
      title: "Assinaturas e Anexos",
      fields: [
        {
          id: "assinatura_cliente",
          label: "Assinatura do Cliente (upload)",
          type: "file",
        },
        {
          id: "assinatura_aplicador",
          label: "Assinatura do Aplicador (upload)",
          type: "file",
        },
        { id: "fotos", label: "Fotos (antes/depois)", type: "file" },
      ],
    },
  ],
};

// ===== Renderers =====
type RendererProps = {
  field: Field;
  value: any;
  onChange: (id: string, value: any) => void;
};

function FieldRenderer({ field, value, onChange }: RendererProps) {
  if (field.type === "repeater") {
    const rep = field as FieldRepeater;
    const items: any[] = Array.isArray(value) ? value : [];
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="font-medium">{field.label}</label>
          <button
            type="button"
            onClick={() => onChange(field.id, [...items, {}])}
            className="px-3 py-1 rounded-lg border hover:bg-gray-50"
          >
            + Adicionar
          </button>
        </div>
        {items.length === 0 && (
          <p className="text-sm text-gray-500">Nenhum item adicionado.</p>
        )}
        <div className="space-y-4">
          {items.map((row, idx) => (
            <div key={idx} className="rounded-xl border p-3">
              <div className="flex items-center justify-between mb-2">
                <div className="text-sm text-gray-600">Item {idx + 1}</div>
                <div className="space-x-2">
                  <button
                    type="button"
                    className="px-2 py-1 rounded border text-xs hover:bg-gray-50"
                    onClick={() => {
                      const next = [...items];
                      next.splice(idx + 1, 0, JSON.parse(JSON.stringify(row)));
                      onChange(field.id, next);
                    }}
                  >
                    Duplicar
                  </button>
                  <button
                    type="button"
                    className="px-2 py-1 rounded border text-xs hover:bg-gray-50"
                    onClick={() => {
                      const next = items.filter((_, i) => i !== idx);
                      onChange(field.id, next);
                    }}
                  >
                    Remover
                  </button>
                </div>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                {rep.children.map((child) => (
                  <SimpleInput
                    key={child.id}
                    field={child}
                    value={row[child.id] ?? ""}
                    onChange={(fid, v) => {
                      const next = [...items];
                      next[idx] = { ...row, [fid]: v };
                      onChange(field.id, next);
                    }}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  return <SimpleInput field={field} value={value} onChange={onChange} />;
}

function SimpleInput({ field, value, onChange }: RendererProps) {
  const base =
    "w-full rounded-xl border px-3 py-2 focus:outline-none focus:ring-2 focus:ring-zinc-400";
  switch (field.type) {
    case "text":
    case "number":
    case "date":
    case "file":
      return (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">
            {field.label}
            {field.required && <span className="text-red-600"> *</span>}
          </label>
          <input
            className={base}
            type={field.type === "text" ? "text" : field.type}
            placeholder={field.placeholder}
            required={field.required}
            value={field.type === "file" ? undefined : (value as any)}
            onChange={(e) => {
              if (field.type === "file") {
                const files = (e.target as HTMLInputElement).files;
                onChange(field.id, files && files[0] ? files[0] : null);
              } else if (field.type === "number") {
                onChange(
                  field.id,
                  (e.target as HTMLInputElement).value === ""
                    ? ""
                    : Number((e.target as HTMLInputElement).value)
                );
              } else {
                onChange(field.id, (e.target as HTMLInputElement).value);
              }
            }}
          />
          {field.description && (
            <p className="text-xs text-gray-500">{field.description}</p>
          )}
        </div>
      );
    case "textarea":
      return (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">
            {field.label}
            {field.required && <span className="text-red-600"> *</span>}
          </label>
          <textarea
            className={cls(base, "min-h-[96px]")}
            placeholder={field.placeholder}
            value={value as any}
            onChange={(e) =>
              onChange(field.id, (e.target as HTMLTextAreaElement).value)
            }
          />
          {field.description && (
            <p className="text-xs text-gray-500">{field.description}</p>
          )}
        </div>
      );
    case "select":
      return (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">
            {field.label}
            {field.required && <span className="text-red-600"> *</span>}
          </label>
          <select
            className={base}
            value={(value as any) || ""}
            onChange={(e) =>
              onChange(field.id, (e.target as HTMLSelectElement).value)
            }
          >
            <option value="">Selecione...</option>
            {(field.options || []).map((op) => (
              <option key={op} value={op}>
                {op}
              </option>
            ))}
          </select>
        </div>
      );
    case "multiselect":
      return (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">
            {field.label}
            {field.required && <span className="text-red-600"> *</span>}
          </label>
          <div className="flex flex-wrap gap-2">
            {(field.options || []).map((op) => {
              const checked = Array.isArray(value)
                ? (value as any[]).includes(op)
                : false;
              return (
                <label
                  key={op}
                  className="flex items-center gap-2 border rounded-xl px-3 py-2 cursor-pointer select-none"
                >
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={(e) => {
                      const isChecked = (e.target as HTMLInputElement).checked;
                      const arr = Array.isArray(value)
                        ? [...(value as any[])]
                        : [];
                      if (isChecked) {
                        if (!arr.includes(op)) arr.push(op);
                      } else {
                        const idx = arr.indexOf(op);
                        if (idx !== -1) arr.splice(idx, 1);
                      }
                      onChange(field.id, arr);
                    }}
                  />
                  <span className="text-sm">{op}</span>
                </label>
              );
            })}
          </div>
        </div>
      );
    case "checkbox":
      return (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">{field.label}</label>
          <div className="flex flex-wrap gap-2">
            {(field.options || []).map((op) => {
              const checked = Array.isArray(value)
                ? (value as any[]).includes(op)
                : false;
              return (
                <label
                  key={op}
                  className="flex items-center gap-2 border rounded-xl px-3 py-2 cursor-pointer select-none"
                >
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={(e) => {
                      const arr = Array.isArray(value)
                        ? [...(value as any[])]
                        : [];
                      if ((e.target as HTMLInputElement).checked) arr.push(op);
                      else {
                        const idx = arr.indexOf(op);
                        if (idx >= 0) arr.splice(idx, 1);
                      }
                      onChange(field.id, arr);
                    }}
                  />
                  <span className="text-sm">{op}</span>
                </label>
              );
            })}
          </div>
        </div>
      );
    case "radio":
      return (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">{field.label}</label>
          <div className="flex flex-wrap gap-4">
            {(field.options || []).map((op) => (
              <label
                key={op}
                className="flex items-center gap-2 cursor-pointer select-none"
              >
                <input
                  type="radio"
                  name={field.id}
                  value={op}
                  checked={value === op}
                  onChange={() => onChange(field.id, op)}
                />
                <span className="text-sm">{op}</span>
              </label>
            ))}
          </div>
        </div>
      );
    case "signature":
      return (
        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium">{field.label}</label>
          <input
            className={base}
            type="file"
            onChange={(e) =>
              onChange(
                field.id,
                (e.target as HTMLInputElement).files?.[0] || null
              )
            }
          />
        </div>
      );
    default:
      return null;
  }
}

// ===== Página =====
export default function FAESFormPage() {
  const [sp] = useSearchParams();
  const osId = sp.get("os_id") || undefined;
  const clientIdFromQuery = sp.get("client_id") || "";

  const [schema, setSchema] = useState<FAESchema | null>(null);
  const [values, setValues] = useState<Record<string, JsonValue>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submissionId, setSubmissionId] = useState<string | null>(null);
  const [selectedClientId, setSelectedClientId] =
    useState<string>(clientIdFromQuery);

  // API
  const { data: order, isLoading: osLoading } = useServiceOrder(osId || 0);
  // client escolhido (se veio via query OU via seletor)
  const { data: selectedClient } = useClientById(selectedClientId || 0);
  // lista p/ seletor quando não veio nada
  const { data: clientsList } = useClients("", "", 100);

  // Carrega schema e defaults
  useEffect(() => {
    const sc = DEFAULT_SCHEMA;
    setSchema(sc);
    setValues(toInitialValues(sc));
  }, []);

  // Quando a OS chegar, preenche cliente + OS + produtos e seta selectedClientId
  useEffect(() => {
    if (!order) return;
    const c = order?.client ?? {};
    const produtos = Array.isArray(order?.lines)
      ? order.lines.map((ln: any) => ({
          produto: safe(ln?.product?.name),
          principio_ativo: safe(ln?.product?.active_ingredient),
          registro_ms: safe(ln?.product?.registration_ms),
          diluente: safe(ln?.diluicao),
          quantidade: safe(ln?.quantidade),
          praga_alvo: safe(ln?.praga),
          equipamento: "",
          antidoto: "",
          lote: "",
          validade: iso(ln?.product?.validity),
        }))
      : [];

    setValues((prev) => ({
      ...prev,
      ...mapClientToFields(c),
      os_numero: safe(order?.public_code) || String(order?.id ?? ""),
      data_emissao: iso(order?.created_at),
      produtos_repeater: produtos,
    }));
    if (c?.id) setSelectedClientId(String(c.id));
  }, [order]);

  // Sempre que o cliente selecionado (por query ou seletor) mudar, preenche identificação
  useEffect(() => {
    if (!selectedClient) return;
    setValues((prev) => ({ ...prev, ...mapClientToFields(selectedClient) }));
  }, [selectedClient]);

  const handleChange = (id: string, v: any) => {
    setValues((prev) => {
      const next = { ...prev };
      setDeep(next, id, v);
      return next;
    });
  };

  const handleSubmit = async (finalizar: boolean) => {
    if (!schema) return;
    setSubmitting(true);
    try {
      const payload = {
        schemaVersion: schema.version,
        schemaTitle: schema.title,
        clientId: selectedClientId || undefined,
        osId,
        data: values,
        finalizar,
        submittedAt: new Date().toISOString(),
      };
      console.log("FAES payload ->", payload);
      // TODO: POST real para tua API quando tiver endpoint /faes
      const id = "FAES-0001";
      setSubmissionId(id);
      alert(
        `Ficha ${finalizar ? "enviada" : "salva"} com sucesso! Código: ${id}`
      );
    } catch (e) {
      console.error(e);
      alert("Erro ao enviar/salvar a ficha");
    } finally {
      setSubmitting(false);
    }
  };

  const clients = clientsList?.items ?? [];
  const canGeneratePdf = Boolean(submissionId);
  if (!schema) return <div className="p-6">Carregando…</div>;

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900">
      <div className="mx-auto max-w-6xl p-4 sm:p-6">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          {/* Barra de contexto com seletor quando não vem os_id */}
          {!osId && (
            <div className="mb-4 rounded-2xl border bg-white p-4 grid grid-cols-1 md:grid-cols-3 gap-3 items-end">
              <div className="md:col-span-2">
                <label className="text-sm font-medium">
                  Selecionar cliente
                </label>
                <select
                  className="w-full rounded-xl border px-3 py-2"
                  value={selectedClientId}
                  onChange={(e) => setSelectedClientId(e.target.value)}
                >
                  <option value="">— Escolha um cliente —</option>
                  {clients.map((c: any) => (
                    <option key={c.id} value={c.id}>
                      {c.name} {c.doc ? `• ${c.doc}` : ""}
                    </option>
                  ))}
                </select>
                <p className="text-xs text-gray-500 mt-1">
                  Ao selecionar, a identificação é preenchida automaticamente.
                </p>
              </div>
              <div className="flex gap-2">
                <a
                  href="/clientes"
                  className="px-3 py-2 rounded-xl border hover:bg-gray-50"
                >
                  Gerenciar clientes
                </a>
              </div>
            </div>
          )}

          {/* Header */}
          <header className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between mb-6">
            <div>
              <h1 className="text-2xl font-semibold">{schema.title}</h1>
              <p className="text-sm text-gray-600">
                {osLoading
                  ? "Carregando OS..."
                  : osId
                  ? `OS: ${values.os_numero || osId}`
                  : "Novo registro"}
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                className="px-4 py-2 rounded-xl border bg-white hover:bg-gray-50"
                onClick={() => handleSubmit(false)}
                disabled={submitting}
              >
                Salvar rascunho
              </button>
              <button
                type="button"
                className="px-4 py-2 rounded-xl border bg-white hover:bg-gray-50"
                onClick={() => handleSubmit(true)}
                disabled={submitting}
              >
                Finalizar
              </button>
              <button
                type="button"
                className={cls(
                  "px-4 py-2 rounded-xl text-white",
                  canGeneratePdf
                    ? "bg-zinc-900 hover:bg-zinc-800"
                    : "bg-gray-400 cursor-not-allowed"
                )}
                onClick={() =>
                  submissionId && alert("PDF (implementar no backend)")
                }
                disabled={!canGeneratePdf}
              >
                Gerar PDF
              </button>
            </div>
          </header>

          {/* Form */}
          <form className="space-y-8">
            {schema.sections.map((section) => (
              <section
                key={section.id}
                className="rounded-2xl border bg-white p-4 sm:p-6 shadow-sm"
              >
                <div className="mb-4">
                  <h2 className="text-lg font-semibold">{section.title}</h2>
                  {section.description && (
                    <p className="text-sm text-gray-600 mt-1">
                      {section.description}
                    </p>
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {section.fields.map((field) => (
                    <div
                      key={field.id}
                      className={[
                        field.type === "repeater"
                          ? "md:col-span-2 lg:col-span-3"
                          : "",
                        field.columns === 2 ? "md:col-span-2" : "",
                        field.columns === 3
                          ? "md:col-span-2 lg:col-span-3"
                          : "",
                      ].join(" ")}
                    >
                      <FieldRenderer
                        field={field}
                        value={(values as any)[field.id]}
                        onChange={handleChange}
                      />
                    </div>
                  ))}
                </div>
              </section>
            ))}
          </form>

          {/* Footer */}
          <footer className="flex flex-wrap gap-2 justify-end mt-6">
            <button
              type="button"
              className="px-4 py-2 rounded-xl border bg-white hover:bg-gray-50"
              onClick={() => handleSubmit(false)}
              disabled={submitting}
            >
              Salvar rascunho
            </button>
            <button
              type="button"
              className="px-4 py-2 rounded-xl border bg-white hover:bg-gray-50"
              onClick={() => handleSubmit(true)}
              disabled={submitting}
            >
              Finalizar
            </button>
            <button
              type="button"
              className={cls(
                "px-4 py-2 rounded-xl text-white",
                canGeneratePdf
                  ? "bg-zinc-900 hover:bg-zinc-800"
                  : "bg-gray-400 cursor-not-allowed"
              )}
              onClick={() =>
                submissionId && alert("PDF (implementar no backend)")
              }
              disabled={!canGeneratePdf}
            >
              Gerar PDF
            </button>
          </footer>
        </motion.div>
      </div>
    </div>
  );
}
